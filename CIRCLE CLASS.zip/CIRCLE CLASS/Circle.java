public class Circle{
	private double radius,pi=3.14159265359;
	
	public void setRadius(double r){
		radius = r;
	}

	public double getRadius(){
		return radius;

	}	

	public double calculateArea(){
		return pi*radius*radius;
	}

}