public class StringBasics{
	public static void main(String str[]){
		String st="AIUB";
		System.out.print(st.indexOf("IUB"));
		String s="AIUB";
		String s2=" CS";
		System.out.println(s);
		System.out.println("length : "+s.length());
		System.out.println("char at : "+s2.charAt(1));
		System.out.println("equals : "+s.equals(s2));
		System.out.println("index : "+s.indexOf("o c"));s
		//System.out.println("sub : "+s.substring(2,6));
		System.out.println("upper : "+s.toLowerCase());
		System.out.println("Concat : "+s.concat(s2));
		System.out.println("Concat : "+s+s2);
		
		System.out.println(s);
		//String class is immutable
		s="by for now";
		System.out.println(s);
		/*
		int b=5;
		String msg=String.valueOf(b);
		System.out.println(msg);
		
		String v="556";
		//int i=v*v;//not possible
		int i=Integer.parseInt(v);
		i=i*i;
		System.out.println(i);*/
	}
}