public class Buffer{
	private Shape record[];
	public Buffer(int s){
		record=new Shape[s];
	}
	public void addShape(Shape s,int idx){
			record[idx]=s;
	}
	public void deleteRect(int idx){
			record[idx]=null;
	}
	public void printAllArea(){
		for(int i=0;i<record.length;i++){
			/*if(record[i]!=null){
				record[i].printArea();
			}*/
			System.out.println(record[i]);
		}
	}
	public void drawAll(){
		for(Shape r:record){
			if(r!=null)
				r.draw();
		}
	}
}