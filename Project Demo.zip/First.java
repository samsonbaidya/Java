import java.awt.Frame;
import java.awt.TextField;
import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Label;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.WindowListener;
import java.awt.event.WindowEvent;
//java api documentation
class First extends Frame implements ActionListener, WindowListener{
	public Login log;
	public Signup sign;
	public Calculator calc;
	public Show show;
	public ComboDemo combo;
	public PaintDemo paint;
	public ImageDemo id;
	public First(){
		super("Java First Window");
		log=new Login(this);
		sign=new Signup(this);
		calc=new Calculator(this);
		show=new Show(this);
		paint=new PaintDemo();
		combo=new ComboDemo();
		id=new ImageDemo();
		Button l=new Button("Login");
		Button s=new Button("Signup");
		Button c=new Button("Calculator");
		Button p=new Button("Paint");
		Button sh=new Button("Show Data");
		Button cmb=new Button("Combo Demo");
		Button idb=new Button("Image Demo");
		add(l);add(s);add(c);add(p);
		add(sh);add(cmb);add(idb);
		l.addActionListener(this);
		s.addActionListener(this);
		c.addActionListener(this);
		p.addActionListener(this);
		sh.addActionListener(this);
		cmb.addActionListener(this);
		idb.addActionListener(this);
		addWindowListener(this);
		setLayout(new FlowLayout());
		setSize(280,400);
	}
	public void actionPerformed(ActionEvent e){
		String s=e.getActionCommand();
		if(s.equals("Login")){
			this.setVisible(false);
			log.setVisible(true);
		}
		else if(s.equals("Signup")){
			sign.setVisible(true);
			this.setVisible(false);
			sign.setParent(this);
		}
		else if(s.equals("Calculator")){
			this.setVisible(false);
			calc.setVisible(true);
			calc.setParent(this);
		}
		else if(s.equals("Show Data")){
			this.setVisible(false);
			show.setVisible(true);
		}
		else if(s.equals("Paint")){
			this.setVisible(false);
			paint.setVisible(true);
		}
		else if(s.equals("Combo Demo")){
			this.setVisible(false);
			combo.setVisible(true);
		}
		else if(s.equals("Image Demo")){
			this.setVisible(false);
			id.setVisible(true);
		}
	}
	public void windowActivated(WindowEvent e){}
	public void windowClosed(WindowEvent e){}
	public void windowClosing(WindowEvent e){
		//this.setVisible(false);
		System.exit(0);
		//System.out.println("Window closing");
	}
	public void windowDeactivated(WindowEvent e){}
	public void windowDeiconified(WindowEvent e){}
	public void windowIconified(WindowEvent e){}
	public void windowOpened(WindowEvent e){}
}