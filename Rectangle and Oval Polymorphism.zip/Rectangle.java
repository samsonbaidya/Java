class Rectangle extends Shape{
	public Rectangle(int w,int h,int x,int y){
		super(w,h,x,y);
	}
	public void printArea(){
		System.out.print("Area of Rectangle :");
		System.out.println(width*height);
	}
	public void draw(){
		System.out.println("Info to Draw Rect");
		System.out.println("X :"+x+", Y:"+y);
		System.out.println("Width :"+width);
		System.out.println("Height :"+height);
	}
}