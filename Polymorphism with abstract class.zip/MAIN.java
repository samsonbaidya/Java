public class MAIN{
    public static void main(String arg[]){
		Student s=new Student(3.9,"raju",99);
		Officer o=new Officer(44444,"mina",90);
		//s.print();
		//o.print();
		s.setAge(90);
		Person p;
		p=s;p.print();
		p=o;p.print();
		
		test(s);
		test(o);
    }
	public static void test(Person t){
		t.print();
	}
}