import java.util.Scanner;

public class main{
	public static void main(String ags[]){
		Scanner input = new Scanner(System.in);
		Circle ob1 = new Circle();
		System.out.println("input the radius of the circle :: ");
		ob1.setRadius(input.nextDouble());
		
		System.out.println("area of the circle is :: " + ob1.calculateArea());

	}


}