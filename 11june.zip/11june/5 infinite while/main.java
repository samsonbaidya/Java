import java.util.Scanner;

public class main{
	public static void main(String args[]){
		
		Scanner input = new Scanner(System.in);
		int x,sum=0;
		
		
		do
		{
			x=input.nextInt();
			sum+=x;
			
		}while(x!=0);
		
		System.out.println(sum);
	}
	
}
