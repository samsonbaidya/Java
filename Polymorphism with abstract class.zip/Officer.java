public class Officer extends Person{
	private int salary;
	public Officer(){
		super("no name",0);
		System.out.println("Officer cons:0");
	}
	public Officer(int s,String n,int a){
		super(n,a);
		this.salary=s;
		System.out.println("Officer cons:3");
	}
	public void print(){
		System.out.println("\nOfficer:");
	    System.out.print(name+" is ");
	    System.out.println(age+" yrs old");
	    System.out.println("Earns: "+salary);
	}
}