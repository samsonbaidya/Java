public class Person{
	protected String name;
	protected int age;
	public Person(){
		System.out.println("Person cons:0");
	}
	public Person(String n,int a){
		this.name=n;
		this.age=a;
		System.out.println("Person cons:2");
	}
	public void setName(String s){this.name=s;}
	public String getName(){return name;}
	public void setAge(int a){age=a;}
	public int getAge(){return age;}
	public void print(){
		System.out.println("Person  : ");
	    System.out.println(name);
	    System.out.println(age);
	}
}