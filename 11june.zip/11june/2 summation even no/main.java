import java.util.Scanner;

public class main{
	public static void main(String args[]){
		int n;
		Scanner input = new Scanner(System.in);
		n = input.nextInt();
		int sum=0;
		int i=4;
		while(i<=n)
		{
			if(i % 2 == 0){
					sum+=i;
			}
		i++;
		}
		
		System.out.println(sum);
		
	}
}
