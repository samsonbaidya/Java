public class Rectangle{
	private double length , width;
	
	public void setLength(double l){
		length = l;
	}
	
	public double getLength(){
		return length;

	}	
	
	public void setWidth(double w){
		width = w;
	}
	
	public double getWidth(){
		return width;
	}

	public double print(){
		return width*length;
	}

}