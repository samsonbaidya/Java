public class Oval extends Shape{
	public Oval(int w,int h,int x,int y){
		super(w,h,x,y);
	}
	public void printArea(){
		System.out.print("Area of Oval :");
		System.out.println(3.14*((width/2)*(width/2)));
	}
	public void draw(){
		System.out.println("Info to Draw Rect");
		System.out.println("X :"+x+", Y:"+y);
		System.out.println("Width :"+width);
		System.out.println("Height :"+height);
	}
}