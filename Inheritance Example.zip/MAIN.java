public class MAIN{
    public static void main(String arg[]){
		Student s=new Student(3.99,"raju",90);
		//s.setCGPA(3.9);
		s.setName("mina");
		s.print();
		s.printSuper();
    }
}