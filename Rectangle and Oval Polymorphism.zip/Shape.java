public abstract class Shape{
	protected int width,height;
	protected int x,y;
	public Shape(){
	}
	public Shape(int w,int h,int x,int y){
		this.width=w;
		this.height=h;
		this.x=x;
		this.y=y;
	}
	public abstract void printArea();
	public abstract void draw();
}