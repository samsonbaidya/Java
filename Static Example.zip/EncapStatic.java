public class EncapStatic{
	public static void main(String args[]){
		Student str[]=new Student[4];
		str[0]=new Student();
		str[2]=new Student();
		Student s=new Student();
		//s.print();
		Student s2=new Student(3.9,"abc",99);
		//s2.print();		
		//Student.setCount(6);
		Student.showCount();
		//Student.c=15; // only if c is public
		//System.out.println(s.c);	//only if c is public and object is cerated
		//System.out.println(s2.c); //only if c is public and object is cerated
		//System.out.println(Student.c); //only if c is public
	}	
}
