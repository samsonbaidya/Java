public class DOB{
	private int day,month,year;
	public DOB(){
		setDay(0);setMonth(0);setYear(1800);
	}
	public DOB(int d,int m,int y){
		setDay(d);setMonth(m);setYear(y);
	}
	public void setDay(int d){
		if(d>31)
			System.out.println("invalid day");
		else
			day=d;
	}
	public void setMonth(int m){month=m;}
	public void setYear(int y){year=y;}
	
	public int getYear(){return year;}
	public int getMonth(){return month;}
	public int getDay(){return day;}
	public void calculateAge(){
	}
	public void show(){
		System.out.println("Your DOB:");
		System.out.println(day+"-"+month+"-"+year);
	}
}