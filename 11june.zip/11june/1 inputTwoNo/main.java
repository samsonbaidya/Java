import java.util.Scanner;

public class main{
	public static void main(String args[]){
		int x,y;
		Scanner input = new Scanner(System.in);
		x = input.nextInt();
		y = input.nextInt();
		int z=1;
		
		for(int i=0 ; i<y ; i++)
		{
			z=z*x;
			
		}
		
		System.out.println(z);
		
	}
}
