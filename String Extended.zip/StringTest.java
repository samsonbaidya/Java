public class StringTest{
    public static void main(String sts[]){
		System.out.println(77+" Raju");
		String s="CS";
		String s2=new String("CS");
		System.out.println(s);
		System.out.println(Integer.toHexString(System.identityHashCode(s)));
		System.out.println(Integer.toHexString(System.identityHashCode(s2)));
		if(s==s2)
			System.out.println("Equal Reference");
		if(s.equals(s2))
			System.out.println("Equal Value");
    }
}