import java.awt.Frame;
import java.awt.TextField;
import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Label;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
public class Window2 extends Frame implements ActionListener{
	private TextField tf;
	private TextField tf2;
	public Window2(){
		super("Java Second Window");
		Label l=new Label("User Name");
		Label l2=new Label("Email");
		tf=new TextField(28);
		tf2=new TextField(28);
		Button b=new Button("Signup");
		add(l);add(tf);
		add(l2);add(tf2);
		add(b);
		l.setBounds(10,35,100,15);
		tf.setBounds(110,35,100,15);
		l2.setBounds(10,55,100,15);
		tf2.setBounds(110,55,100,15);
		b.setBounds(210,85,100,25);
		b.addActionListener(this);
		setLayout(null);
		setSize(400,300);
		setLocation(400,200);
		setVisible(true);
	}
	public void actionPerformed(ActionEvent ae){
		System.out.println("Button Pressed");
		String s=ae.getActionCommand();
		DataAccess da=new DataAccess();
		String q="";
		if(s.equals("Signup")){
			q="insert into `record` values(null,'"+tf.getText()+"','"+tf2.getText()+"')";
			System.out.println(q);
			da.updateDB(q);
		}
	}
}