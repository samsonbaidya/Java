public class MAIN{
    public static void main(String arg[]){
		DOB db=new DOB(5,3,1997);
		System.out.println(db);
		Student s=new Student(3.9,"raju",90,db);
		s.print();
		//s.printSuper();
    }
}