import java.awt.Frame;
import java.awt.TextField;
import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Label;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

//java api documentation
class First extends Frame implements ActionListener{
	public Login log;
	public Signup sign;
	public Calculator calc;
	public First(){
		super("Java First Window");
		log=new Login(this);
		sign=new Signup(this);
		calc=new Calculator(this);
		
		Button l=new Button("Login");
		Button s=new Button("Signup");
		Button c=new Button("Calculator");
		add(l);add(s);add(c);
		l.addActionListener(this);
		s.addActionListener(this);
		c.addActionListener(this);
		setLayout(new FlowLayout());
		setSize(280,400);
		setVisible(true);
	}
	public void actionPerformed(ActionEvent e){
		String s=e.getActionCommand();
		if(s.equals("Login")){
			this.setVisible(false);
			log.setVisible(true);
			log.setParent(this);
		}
		else if(s.equals("Signup")){
			sign.setVisible(true);
			sign.setParent(this);
			this.setVisible(false);
		}
		else if(s.equals("Calculator")){
			calc.setVisible(true);
			calc.setParent(this);
		}
	}
}