public class Student{
    private double cgpa;
	private String name;
	private int age;
	private static int c;
	public Student(){
		name="no name";
		//age=0;
		//cgpa=0.0;
		c++;
	}
	public Student(double cg,String n,int a){
		name=n;cgpa=cg;age=a;
		c++;
	}
	public void setAge(int a){
		this.age=a;
	}
	public static void setCount(int co){
		c=co;
	}
	public static void showCount(){
		System.out.println(c);
	}
    public void setCGPA(double cgpa){
        this.cgpa=cgpa;
    }
    public double getCGPA(){
        return this.cgpa;
    }
    public void print(){
		System.out.println("Student Info: ");
	    System.out.println(cgpa);
	    System.out.println(name);
	    System.out.println(age);
    }
}