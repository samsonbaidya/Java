import java.util.Scanner;

public class main{
	public static void main(String args[]){
		int arr[]={1,3,5,6,7,9,10,11,13,17,18,21,22,23,24,25,26};

		for(int i = 0 ; i < arr.length ; i++)
		{
			if(arr[i] >1){
				for(int j = 2 ; j<arr[i] ; j++){
					if(arr[i]%j == 0 ){
						break;
					}
					else{
						System.out.println(arr[i] + " is prime");
						break;
					}
				}
			}
		}	
	}
}
