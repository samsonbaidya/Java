public class Force{
	private double acceleration , mass;
	
	public void setAcceleration(double a){
		acceleration = a;
	}
	
	public double getAcceleration(){
		return acceleration;

	}	
	
	public void setMass(double m){
		mass = m;
	}
	
	public double getMass(){
		return mass;
	}

	public double printForce(){
		return acceleration*mass;
	}

}