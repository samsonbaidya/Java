public class Student extends Person{
    private double cgpa;
	private DOB dateOfBirth;
	public Student(){
		setName("no name");
		setAge(0);cgpa=0.0;
		System.out.println("Student cons:0");
	}
	public Student(double c,String n,int a,DOB d){
		//super(n,a);
		name=n; age=a;
		//setName(n);setAge(a);
		dateOfBirth=d;
		cgpa=c;
		System.out.println("Student cons:3");
	}
    public void setCGPA(double cg){cgpa=cg;}
    public double getCGPA(){return cgpa;}
	public void print(){ // method overriding
		//super.print();
		System.out.println("Student: ");
	    System.out.println(cgpa);
	    System.out.println(getName());
	    System.out.println(getAge());
		dateOfBirth.show();
    }
	public void printSuper(){
		super.print();
	}
}