public class Student extends Person{
    private double cgpa;
	public Student(){
		setName("no name");
		setAge(0);cgpa=0.0;
		System.out.println("Student cons:0");
	}
	public Student(double c,String n,int a){
		setName(n);setAge(a);cgpa=c;
		System.out.println("Student cons:3");
	}
    public void setCGPA(double cg){cgpa=cg;}
    public double getCGPA(){return cgpa;}
    public void print(){ // method overriding
		System.out.println("Student: ");
	    System.out.println(cgpa);
	    System.out.println(getName());
	    System.out.println(getAge());
    }
	public void printSuper(){
		super.print();
	}
}