import java.awt.Frame;
import java.awt.TextField;
import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Label;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
class Calculator extends Frame implements ActionListener{
	private TextField tf;
	private TextField tf2;
	public Calculator(){
		super("Java Calculator");
		Label l=new Label("Value 1");
		Label l2=new Label("Value 2");
		tf=new TextField(28);
		tf2=new TextField(28);
		Button b=new Button("+");
		Button b2=new Button("-");
		add(l);add(tf);
		add(l2);add(tf2);
		add(b);add(b2);
		b.addActionListener(this);
		b2.addActionListener(this);
		setLayout(new FlowLayout());
		setSize(280,400);
		setLocation(500,200);
		setVisible(true);
	}
	public void actionPerformed(ActionEvent ae){
		System.out.println(tf.getText());
		System.out.println(tf2.getText());
		System.out.println(ae.getActionCommand());
	}
}


