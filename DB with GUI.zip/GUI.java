import java.awt.Frame;
import java.awt.TextField;
import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Label;
public class GUI{
	public static void main(String s[]){
		Window w=new Window();
		Window2 w2=new Window2();
		Calculator c=new Calculator();
	}
}

