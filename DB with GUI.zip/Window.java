import java.awt.Frame;
import java.awt.TextField;
import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Label;
class Window extends Frame{
	public Window(){
		super("Java First Window");
		Label l=new Label("User Name");
		Label l2=new Label("Password");
		TextField tf=new TextField(28);
		TextField tf2=new TextField(28);
		Button b=new Button("Login");
		add(l);add(tf);
		add(l2);add(tf2);
		add(b);
		setLayout(new FlowLayout());
		setSize(280,400);
		setVisible(true);
	}
}