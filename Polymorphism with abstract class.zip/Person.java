public abstract class Person{
	protected String name;
	protected int age;
	public Person(){
		System.out.println("Person cons:0");
	}
	public Person(String n,int a){
		//setName(n);
		this.name=n;
		this.age=a;
		System.out.println("Person cons:2");
	}
	public final void setName(String s){this.name=s;}
	public final String getName(){return name;}
	public final void setAge(int a){age=a;}
	public final int getAge(){return age;}
	public abstract void print();
}