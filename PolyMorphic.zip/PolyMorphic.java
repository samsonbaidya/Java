abstract class Department{
	private String deptName;
	public void setDeptName(String n){
		deptName=n;
	}
	public String getDeptName(){return this.deptName;}
	public final void showInfo(){
		System.out.println(this.deptName);
	}
	public abstract void calculateSemFee(int tc);
}
class  CS extends Department{
	public void calculateSemFee(int tc){
		
	}
}
class  BBA extends Department{
	public void calculateSemFee(int tc){
		
	}
}
class Student{
	private Department d;
	private String name;
	public Student(String n){this.name=n;}
	public void setDepartment(Department d){
		this.d = d;
	}
	public void print(){
		System.out.print(name+" is under ");
		d.showInfo();
	}
	public void semesterFee(int totalCredit){
		d.calculateSemFee(totalCredit);
	}
}
public class PolyMorphic {
	public static void main(String [] arg){
		CS cs=new CS();
		cs.setDeptName("CS");
		BBA bba = new BBA();
		bba.setDeptName("BBA");
		
		Student std = new Student("abc");
		std.setDepartment(bba);	//std is under BBA dept from now
		std.print();
		std.semesterFee(6);
		
		Student std2 = new Student("xyz");
		std2.setDepartment(cs);	//std2 is under CS dept from now
		std2.print();
		std2.semesterFee(3);
	}
}
