public class Student extends Person{
    private double cgpa;
	public Student(){
		super("no name",0);
		System.out.println("Student cons:0");
	}
	public Student(double c,String n,int a){
		super(n,a);
		this.cgpa=c;
		System.out.println("Student cons:3");
	}
    public void setCGPA(double cg){cgpa=cg;}
    public double getCGPA(){return cgpa;}
	public void print(){ // method overriding
		System.out.println("\nStudent: ");
	    System.out.print(name+" is ");
	    System.out.println(age+" yrs old");
	    System.out.println("Obtained: "+cgpa);
    }
}