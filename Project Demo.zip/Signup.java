import java.awt.*;
import java.awt.event.*;
import javax.swing.JOptionPane;
public class Signup extends Frame implements ActionListener{
	private TextField tf;
	private TextField tf2;
	private First first;
	private Frame parent;
	public Signup(First f){
		super("Java Second Window");
		first=f;
		Label l=new Label("User Name");
		Label l2=new Label("Password");
		tf=new TextField(28);
		tf2=new TextField(28);
		Button b=new Button("Signup");
		Button b2=new Button("Cancel");
		add(l);add(tf);
		add(l2);add(tf2);
		add(b);add(b2);
		l.setBounds(10,35,100,15);
		tf.setBounds(110,35,100,20);
		l2.setBounds(10,55,100,15);
		tf2.setBounds(110,55,100,20);
		b.setBounds(110,85,100,25);
		b2.setBounds(10,85,100,25);
		b.addActionListener(this);
		b2.addActionListener(this);
		setLayout(null);
		setSize(400,300);
		setLocation(400,200);
	}
	public void actionPerformed(ActionEvent ae){
		System.out.println("Button Pressed");
		String s=ae.getActionCommand();
		System.out.println(s);
		if(s.equals("Signup")){
			if(tf.getText().length()==0 || tf2.getText().length()==0){
				JOptionPane.showMessageDialog(this,"You Must Type");
			}
			else{
				String q="insert into student values(null,'"+tf.getText()+"','"+tf2.getText()+"','0.0','CS','1')";
				System.out.println(q);
				DataAccess da=new DataAccess();
				da.updateDB(q);
			}
		}
		else if(s.equals("Cancel")){
			first.setVisible(true);
			this.setVisible(false);
		}
	}
	public void setParent(Frame f){parent=f;}
}