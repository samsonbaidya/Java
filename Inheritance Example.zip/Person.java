public class Person{
	private String name;
	private int age;
	public void setName(String s){this.name=s;}
	public String getName(){return name;}
	public void setAge(int a){age=a;}
	public int getAge(){return age;}
	public void print(){
		System.out.println("Person  : ");
	    System.out.println(name);
	    System.out.println(age);
	}
}