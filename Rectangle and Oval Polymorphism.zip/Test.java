public class Test{
	public static void main(String a[]){
		Rectangle r=new Rectangle(4,3,1,1);
		Rectangle r2=new Rectangle(10,4,6,7);
		
		Oval o=new Oval(11,11,6,7);
		Oval o2=new Oval(9,9,4,9);
		
		//test(r);test(r2);
		//test(o);test(o2);
		
		Buffer b=new Buffer(4);
		//b.addShape(r,0);
		b.addShape(r2,1);
		b.addShape(o,2);
		//b.addShape(o2,3);
		b.printAllArea();
		//b.drawAll();
	}
	public static void test(Shape s){
		s.printArea();
		s.draw();
	}
}