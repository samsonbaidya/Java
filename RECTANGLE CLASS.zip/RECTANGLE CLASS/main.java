import java.util.Scanner;

public class main{
	public static void main(String ags[]){
		Scanner input = new Scanner(System.in);
		Rectangle ob1 = new Rectangle();
		System.out.println("input the length of the rectangle :: ");
		ob1.setLength(input.nextDouble());
		
		System.out.println("input the width of the rectangle :: ");
		ob1.setWidth(input.nextDouble());

		System.out.println("area of the rectangle is :: " + ob1.print());

	}


}