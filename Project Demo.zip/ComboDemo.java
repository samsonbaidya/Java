import java.awt.*;
import java.awt.event.*;
import java.awt.Choice;
import java.sql.ResultSet;
import java.sql.SQLException;
class ComboDemo extends Frame implements ItemListener{
	public String msg;
	private String dept[]={"CS","BBA","EEE"};
	private String students[]={"raju","mina"};
	Choice cityChoice=new Choice();
	Choice stuChoice=new Choice();
	public ComboDemo(){
		super("Java Combo Window");
		cityChoice.add("Dhaka");
		cityChoice.add("Chittagong");
		add(cityChoice);
		add(stuChoice);
		cityChoice.addItemListener(this);
		stuChoice.addItemListener(this);
		setSize(600,400);
		setLayout(new FlowLayout());
	}
	public void itemStateChanged(ItemEvent ie){
		String v=(String)ie.getItem();
		if(ie.getSource()==stuChoice){
			System.out.println(stuChoice.getSelectedItem()+" selected");
		}
		else if(ie.getSource()==cityChoice){
			System.out.println(v+" selected");
			loadStudents(v);
		}
		
	}
	public void loadStudents(String city){
		int l=0;ResultSet rs=null;
		stuChoice.removeAll();
		String sq="select name from student s, location l where l.city ='"+city+"' and s.locid=l.locid";
		try{
			DataAccess da=new DataAccess();
			rs=da.getData(sq);
			while(rs.next()){
				sq=rs.getString("name");
				if(sq.length()>l)l=sq.length();
				stuChoice.add(sq);
			}
			stuChoice.setSize(l*15,0);
		}
		catch(Exception ex){ex.printStackTrace();}
	}
}