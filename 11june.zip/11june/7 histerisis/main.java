import java.util.Scanner;

public class main{
	public static void main(String args[]){
		int arr[]={6,2,14,5,8};
		
		for(int i = 0 ; i < arr.length ; i++)
		{
			System.out.print(arr[i]+ " : ");
			for(int x = 0 ; x<arr[i] ; x++){
				System.out.print("*");
			}	
			System.out.print("\n");
		}
		
		
	}
}
