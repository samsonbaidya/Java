public class MAIN{
    public static void main(String arg[]){
		Student s=new Student(3.9,"raju",99);
		Officer o=new Officer(44444,"mina",90);
		
		Person p;
		//System.out.println(p);
		p=s;
		p.print();
		
		p=o;
		p.print();
		
		test(s);
		test(o);
    }
	public static void test(Person st){
		st.print();
	}
}