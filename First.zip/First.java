import java.util.Scanner;
public class First{
	public static void main(String arg[]){
		int marks=90;
		Scanner sc=new Scanner(System.in);
		marks=sc.nextInt();
		if(marks>50){
			System.out.println("passed");
		}
		else{
			System.out.println("failed!");
		}
		System.out.println("Hello Java");
	}
}