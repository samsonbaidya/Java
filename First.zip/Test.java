public class Test{
	public static void main(String s[]){
		//System.out.println(s.length);
		//System.out.println("hello "+s[0]);
		//System.out.println(s[1]);
		int a=5;
		int b=8;
		System.out.println("Test class "+(a+b));
		
	}
}