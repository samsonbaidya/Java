import java.util.Scanner;

public class main{
	public static void main(String args[]){
		int arr[]={1,3,5,6,7,9,10};
		System.out.println("input a number to find in the array : ");
		Scanner input = new Scanner(System.in);
		int s = input.nextInt();
		for(int i=0 ; i<arr.length ; i++)
		{
			if(arr[i] == s)
			{
				System.out.println("value is found in the array in index " + i);
			}
			else 
				System.out.println("value not found");
					break;
				
		}
	}
	
}
