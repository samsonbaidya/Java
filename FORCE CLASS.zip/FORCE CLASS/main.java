import java.util.Scanner;

public class main{
	public static void main(String ags[]){
		Scanner input = new Scanner(System.in);
		Force ob1 = new Force();
		System.out.println("input the acceleration of a bullet:: ");
		ob1.setAcceleration(input.nextDouble());
		
		System.out.println("input the mass of a bullet:: ");
		ob1.setMass(input.nextDouble());

		System.out.println("force of the bullet is :: " + ob1.printForce());

	}


}
